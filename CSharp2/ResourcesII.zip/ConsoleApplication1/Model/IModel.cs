﻿namespace Model
{
	public interface IModel
	{
		int Id { get; }
	}
}
