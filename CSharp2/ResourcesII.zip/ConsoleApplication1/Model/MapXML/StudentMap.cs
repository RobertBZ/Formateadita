﻿using System;

namespace Model.MapXML
{
	public class StudentMap : AbstractMap
	{
		public override IModel ToModel(string str)
		{
			throw new NotImplementedException();
		}
	}
}
