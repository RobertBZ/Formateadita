﻿using System;

namespace Model.MapXML
{
    public class CareerMap : AbstractMap
    {
	    public override IModel ToModel(string str)
	    {
		    throw new NotImplementedException();
	    }
    }
}
